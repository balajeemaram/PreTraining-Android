public class Person
{
	public String name;
	public String address;

	public Person(String n, String address)
	{
	  name = n;
this.address=address;
	}
String getName()
{
return this.name;
}
String getAddress()
{
return this.address;
}
void setAddress(String address)
{
this.address=address;
}
	public String toString()
	{
	  return "Person[name=" + name + ",address=" + address + "]";
	}
}