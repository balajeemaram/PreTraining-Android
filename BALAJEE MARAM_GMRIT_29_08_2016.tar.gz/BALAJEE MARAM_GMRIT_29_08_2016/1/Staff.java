public class Staff extends Person
{
	public String school;
public double pay;

	public Staff(String name, String address, String school, double pay)

    {
      super(name, address);
this.school=school;
this.pay=pay;
    }
String getSchool()
{
return(this.school);
}
void setSchool(String school)
{
this.school=school;
}
double getPay()
{
return(this.pay);
}
void setPay(double pay)
{
this.pay=pay;
}

    public String toString()
    {
      return "Employee[super=" + super.toString() + ",school=" + school + ",pay=" + pay+"]";
    }
}