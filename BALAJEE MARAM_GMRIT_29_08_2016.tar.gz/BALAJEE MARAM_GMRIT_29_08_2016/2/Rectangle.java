import java.io.*;
class Rectangle extends Shape
{
    double length;
    double width;
    Rectangle()
   {
   length=5;
   width=5;
   }
    Rectangle(double length, double width)
    {
        this.length = length;
        this.width = width;
    }
      Rectangle(double length, double width,String color, boolean filled)
    {
        this.length = length;
        this.width = width;
        this.color=color;
        this.filled=filled;
    }
    double getWidth()
    {
        return width;
    }
    void setWidth(double width)
	{
	this.width=width;
	}
    void setLength(double length)
	{
	this.length=length;
	}
double getLength()
	{
	return (this.length);
	}
public double getArea()
    {
        return length * width;
    }
public double getPerimeter()
{
return (2*(length+width));
}
public String toString()
{
return ("End of program");
}
}