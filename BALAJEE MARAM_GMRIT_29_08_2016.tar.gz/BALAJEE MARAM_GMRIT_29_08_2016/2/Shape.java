/* File name : Shape.java */
public abstract class Shape
{
   public String color;
   public boolean filled;
   public Shape()
   {
	color="Red";
	filled=false;
   }
   public Shape(String color,boolean filled)
   {
      System.out.println("Constructing a Shape");
      this.color = color;
      this.filled = filled;
   }
   public String getColor()
   {
     System.out.println("Inside getColor()");
     return color;
   }
   public void setColor(String color)
   {
	this.color=color;
      System.out.println("Old Color:" + color
       + "New Color: " + this.color);
   }
   public boolean isFilled()
   {
	if(filled==true)
	return true;
	else
	return false;      

   }
   public boolean setFilled(boolean filled)
   {
      this.filled=filled;
	return this.filled;
   }
   abstract public double getArea();
   abstract public double getPerimeter();
   abstract public String toString(); 
}
