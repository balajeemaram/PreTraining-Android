public class Circle extends Shape{

    private final double PI = 3.14159;
    private double radius;

    public Circle() {
        radius = 0.0;
    }

    public Circle(double r) {
        radius = r;
    }
    public Circle(double r, String color, boolean filled)
    {
	radius=r;
      this.color=color;
	this.filled=filled;
    }

    public void setRadius(double r) {
        radius = r;
    }

    public double getRadius() {
        return radius;
    }

    public double getArea() {
        return PI * radius * radius;
    }


    public double getPerimeter() {
        return 2 * PI * radius;
    }
	public String toString()
	{
	return ("end of program");
	}

public static void main(String[] args) {

    System.out.print("Enter the radius of a circle: ");
    Circle circle = new Circle(10);

    // Display circle information
    System.out.println("Area is " + circle.getArea());
    System.out.println("Circumference is " + circle.getPerimeter());

}
}